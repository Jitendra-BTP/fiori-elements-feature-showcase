sap.ui.define(["sap/m/MessageBox", "sap/ui/core/mvc/ControllerExtension"], function (MessageBox, ControllerExtension) {
  "use strict";

  /**
   * @namespace sap.fe.showcase.lrop.ext.controller
   */
  const RootEntityLRExtension = ControllerExtension.extend("sap.fe.showcase.lrop.ext.controller.RootEntityLRExtension", {
    messageBox: function _messageBox() {
      MessageBox.alert("Button pressed");
    },
    enabled: function _enabled() {
      return true;
    },
    enabledForSingleSelect: function _enabledForSingleSelect(_, aSelectedContexts) {
      if (aSelectedContexts && aSelectedContexts.length === 1) {
        return true;
      }
      return false;
    },
    onResetRating: function _onResetRating(_) {
      // @ts-expect-error setFiltersValues has faulty type atm
      this.base.getExtensionAPI().setFilterValues("starsValue");
    },
    isCreateEnabled: function _isCreateEnabled(value, parentContext) {
      switch (parentContext?.getProperty("category_code")) {
        case "03":
          return value === "02";
        // Only Divisions under Business Units
        case "02":
          return value === "01";
        // Only Departments under Divisions
        case "01":
          return false;
        // Nothing under Departments
        default:
          return value === "03";
        // Only Business Units at root level
      }
    },
    isMoveToPositionAllowed: function _isMoveToPositionAllowed(sourceContext, parentContext) {
      switch (parentContext?.getProperty("category_code")) {
        case "03":
          return sourceContext?.getProperty("category_code") === "02";
        case "02":
          return sourceContext?.getProperty("category_code") === "01";
        case "01":
          return false;
        // Nothing under Departments
        default:
          return false;
      }
    },
    isNodeMovable: function _isNodeMovable(sourceContext) {
      // Keep in mind getProperty does only return loaded property & 
      // that via personalisation a user could hide properties assumed to exist
      return sourceContext.getProperty('name') !== 'Compilance';
    },
    isNodeCopyable: function _isNodeCopyable(sourceContext) {
      return sourceContext.getProperty('name') !== 'Compilance';
    },
    isCopyToPositionAllowed: function _isCopyToPositionAllowed(sourceContext, parentContext) {
      switch (parentContext?.getProperty("category_code")) {
        case "03":
          return sourceContext?.getProperty("category_code") === "02" || sourceContext?.getProperty("category_code") === "01";
        case "02":
          return sourceContext?.getProperty("category_code") === "01";
        case "01":
          return false;
        // Nothing under Departments
        default:
          return false;
      }
    }
  });
  return RootEntityLRExtension;
});
//# sourceMappingURL=RootEntityLRExtension-dbg.controller.js.map
