sap.ui.define(["sap/m/MessageBox", "sap/ui/core/mvc/ControllerExtension"], function (MessageBox, ControllerExtension) {
  "use strict";

  /**
   * @namespace sap.fe.showcase.lrop.ext.controller
   */
  const RootEntityOPExtension = ControllerExtension.extend("sap.fe.showcase.lrop.ext.controller.RootEntityOPExtension", {
    messageBox: function _messageBox() {
      MessageBox.alert("Button pressed");
    },
    enabled: function _enabled() {
      return true;
    },
    enabledForSingleSelect: function _enabledForSingleSelect(_, aSelectedContexts) {
      if (aSelectedContexts && aSelectedContexts.length === 1) {
        return true;
      }
      return false;
    },
    toggleSideContent: function _toggleSideContent(_) {
      this.base.getExtensionAPI().showSideContent("customSectionQualifier");
    },
    toggleSideContentItem1: function _toggleSideContentItem(_) {
      this.base.getExtensionAPI().showSideContent("childEntities1Section");
    },
    //Search-Term: #EditFlowAPI
    onChangeCriticality: function _onChangeCriticality(oEvent) {
      const sActionName = "LROPODataService.changeCriticality";
      this.base.getExtensionAPI().getEditFlow().invokeAction(sActionName, {
        contexts: oEvent.getSource().getBindingContext(),
        model: oEvent.getSource().getModel(),
        label: 'Confirm',
        invocationGrouping: "ChangeSet"
      }); //SAP Fiori elements EditFlow API
    }
  });
  return RootEntityOPExtension;
});
//# sourceMappingURL=RootEntityOPExtension-dbg.controller.js.map
