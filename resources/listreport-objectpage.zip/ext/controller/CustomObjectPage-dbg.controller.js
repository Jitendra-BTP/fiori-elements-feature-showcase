sap.ui.define(["sap/fe/core/PageController", "sap/suite/ui/microchart/ComparisonMicroChart", "sap/suite/ui/microchart/ComparisonMicroChartData", "sap/ui/model/json/JSONModel"], function (PageController, ComparisonMicroChart, ComparisonMicroChartData, JSONModel) {
  "use strict";

  /**
   * @namespace sap.fe.showcase.lrop.ext.controller
   * @controller
   */
  const CustomObjectPage = PageController.extend("sap.fe.showcase.lrop.ext.controller.CustomObjectPage", {
    onInit: function _onInit() {
      PageController.prototype.onInit.apply(this);
      const model = new JSONModel(sap.ui.require.toUrl("sap/fe/showcase/lrop/ext/controller/data.json"));
      this.getView()?.setModel(model, 'graph');
      this._modelSettings = new JSONModel({
        source: "atomicCircle",
        orientation: "LeftRight",
        arrowPosition: "End",
        arrowOrientation: "ParentOf",
        nodeSpacing: 55,
        mergeEdges: false
      });
      this.getView()?.setModel(this._modelSettings, "settings");
      const fnSetContent = function (node) {
        node.setContent(new ComparisonMicroChart({
          size: "M",
          scale: "M",
          data: [new ComparisonMicroChartData({
            title: "USA",
            value: Math.floor(Math.random() * 60),
            color: "Neutral"
          }), new ComparisonMicroChartData({
            title: "EMEA",
            value: Math.floor(Math.random() * 60),
            color: "Error"
          }), new ComparisonMicroChartData({
            title: "APAC",
            value: -20,
            color: "Good"
          }), new ComparisonMicroChartData({
            title: "LTA",
            value: Math.floor(Math.random() * 60) * -1,
            color: "Critical"
          }), new ComparisonMicroChartData({
            title: "ALPS",
            value: Math.floor(Math.random() * 20),
            color: "Good"
          })]
        }).addStyleClass("sapUiSmallMargin"));
      };
      model.attachRequestCompleted(() => {
        this.byId("graph").getNodes().forEach(function (node) {
          if (node.getKey() === "21" || node.getKey() === "18") {
            fnSetContent(node);
          }
        });
      });
    },
    onAfterRendering: function _onAfterRendering() {
      this.byId("graphWrapper")?.$().css("overflow-y", "auto");
    },
    mergeChanged: function _mergeChanged(oEvent) {
      this._modelSettings.setProperty("/mergeEdges", !!Number(oEvent.getSource().getProperty("selectedKey")));
    },
    spacingChanged: function _spacingChanged(oEvent) {
      this._modelSettings.setProperty("/nodeSpacing", Number(oEvent.getSource().getProperty("selectedKey")));
    }
  });
  return CustomObjectPage;
});
//# sourceMappingURL=CustomObjectPage-dbg.controller.js.map
