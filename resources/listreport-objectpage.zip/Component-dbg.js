sap.ui.define(["sap/fe/core/AppComponent"], function (AppComponent) {
  "use strict";

  /**
   * @namespace sap.fe.showcase.lrop
   */
  const Component = AppComponent.extend("sap.fe.showcase.lrop.Component", {
    metadata: {
      manifest: 'json'
    }
  });
  return Component;
});
//# sourceMappingURL=Component-dbg.js.map
