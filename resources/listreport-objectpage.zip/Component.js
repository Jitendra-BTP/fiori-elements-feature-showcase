sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";const n=e.extend("sap.fe.showcase.lrop.Component",{metadata:{manifest:"json"}});return n});
//# sourceMappingURL=Component.js.map