import AppComponent from 'sap/fe/core/AppComponent';

/**
 * @namespace sap.fe.showcase.lrop
 */
export default class Component extends AppComponent {
  public static metadata = {
    manifest: 'json',
  };
}
