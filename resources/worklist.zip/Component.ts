import AppComponent from 'sap/fe/core/AppComponent';

/**
 * @namespace sap.fe.showcase.worklist
 */
export default class Component extends AppComponent {
  public static metadata = {
    manifest: 'json',
  };
}
