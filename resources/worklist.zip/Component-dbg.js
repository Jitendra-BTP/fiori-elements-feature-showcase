sap.ui.define(["sap/fe/core/AppComponent"], function (AppComponent) {
  "use strict";

  /**
   * @namespace sap.fe.showcase.worklist
   */
  const Component = AppComponent.extend("sap.fe.showcase.worklist.Component", {
    metadata: {
      manifest: 'json'
    }
  });
  return Component;
});
//# sourceMappingURL=Component-dbg.js.map
